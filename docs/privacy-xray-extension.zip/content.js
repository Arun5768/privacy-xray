(() => {
  // src/content.ts
  function post(protect) {
    window.postMessage({ __pxrCfg: true, protect }, "*");
  }
  function send(msg) {
    try {
      chrome.runtime.sendMessage(msg).catch(() => {
      });
    } catch {
    }
  }
  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.__pxr !== true) return;
    send({ type: "from-page", kind: e.data.kind, payload: e.data.payload });
  });
  try {
    chrome.runtime.sendMessage({ type: "getConfig" }).then((c) => c && post(!!c.protect)).catch(() => {
    });
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === "config") post(!!msg.protect);
    });
  } catch {
  }
})();
